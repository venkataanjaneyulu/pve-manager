Ext.define('Pandora.store.RecentSongs', {
    extend: 'Ext.data.Store',
    requires: 'Pandora.model.Song',    
    model: 'Pandora.model.Song'
});